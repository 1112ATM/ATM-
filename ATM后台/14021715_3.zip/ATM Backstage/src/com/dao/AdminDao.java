package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.model.Admin;


/**
 * ����ԱDao��
 * @author dell
 *
 */
public class AdminDao {
	
	/**
	 * ��¼��֤
	 * @param con
	 * @param user
	 * @return
	 * @throws Exception
	 */
	public Admin login(Connection con,Admin admin)throws Exception{
		Admin resultUser = null;
		String sql="select * from admin where account=? and password=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, admin.getAccount());
		pstmt.setString(2, admin.getPassword());
		ResultSet rs = pstmt.executeQuery();
		if(rs.next()) {
			resultUser = new Admin();
			resultUser.setId(rs.getInt("id"));
			resultUser.setAccount(rs.getString("account"));
			resultUser.setPassword(rs.getString("password"));
		}
		return resultUser;
	}

}
